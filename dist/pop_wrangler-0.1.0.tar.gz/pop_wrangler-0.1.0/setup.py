# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['pop_wrangler',
 'pop_wrangler.analytics',
 'pop_wrangler.analytics.excelerator',
 'pop_wrangler.analytics.pdf_parsing',
 'pop_wrangler.flask_app',
 'pop_wrangler.flask_app.files',
 'pop_wrangler.flask_app.files.sales_data',
 'pop_wrangler.flask_app.files.sales_data.historic',
 'pop_wrangler.flask_app.files.tmp_files',
 'pop_wrangler.flask_app.tmpdir']

package_data = \
{'': ['*'], 'pop_wrangler': ['utils/*']}

install_requires = \
['XlsxWriter>=1.1,<2.0',
 'flask-cors>=3.0,<4.0',
 'flask>=1.0,<2.0',
 'natsort>=6.0,<7.0',
 'numpy>=1.16,<2.0',
 'openpyxl>=2.6,<3.0',
 'pandas>=0.24.2,<0.25.0',
 'pdfminer.six>=20181108.0,<20181109.0',
 'plotly>=3.9,<4.0',
 'python-dotenv>=0.10.3,<0.11.0',
 'xlrd>=1.2,<2.0']

setup_kwargs = {
    'name': 'pop-wrangler',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'MTempleman',
    'author_email': 'huntertempleman@gmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
